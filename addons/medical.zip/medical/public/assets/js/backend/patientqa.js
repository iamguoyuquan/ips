define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'patientqa/index'  + location.search,
                    add_url: 'patientqa/add',
                    edit_url: 'patientqa/edit',
                    del_url: 'patientqa/del',
                    table: 'patientqa',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {field: 'patient.name', title: __('Name')},
                        {field: 'question', title: __('question')},
                        {field: 'answer', title: __('answer')},
                        {field: 'createtime', title: __('Createtime'), formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass: 'datetimerange'},
                        {field: 'updatetime', title: __('Updatetime'), formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass: 'datetimerange'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ],
                queryParams: function (params){
                    if(params.filter == '{}'){
                        params.filter =  JSON.stringify({answer: ''})
                        params.op =  JSON.stringify({answer: '='})
                    }
                    return params;
                },
                onClickRow: function (item, $element) {
                    $.ajax({
                        url: "patientqa/history",
                        type: 'post',
                        dataType: 'json',
                        data: {patient_id: item.patient_id},
                        success: function (ret) {
                            if (ret.hasOwnProperty("code")) {
                                let data = ret.hasOwnProperty("data") && ret.data != "" ? ret.data : "";
                                if (ret.code === 1) {
                                    // //销毁已有的节点树
                                    // $("#treeview").jstree("destroy");
                                    Controller.api.renderList(data);
                                } else {
                                    Backend.api.toastr.error(ret.msg);
                                }
                            }
                        }, error: function (e) {
                            Backend.api.toastr.error(e.message);
                        }
                    });
                },
            });

        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            },
            renderList: function(data){
                var s = '';
                data.forEach(x => {
                    var reply = '';
                    if(!! x.answer){
                        reply = "答:" +  x.answer + "";
                    }else{
                        reply = "去回答";
                    }

                    s += '\
                    <div class="timeline "> \
                    <span class="timeline-icon"></span> \
                    <span class="year">'  + x.createtime +  '</span> \
                    <div class="timeline-content"> \
                    <div class="description">问:'+ x.question +'</div> \
                    <div class="description">'+ reply +'</div> \
                    </div> \
                </div>';
                })
                
                $('#qaList').html(s);
            }
        }
    };
    return Controller;
});