<?php

return [
    'name'        => '名称',
    'level'        => '等级',
    'logo'        => 'Logo',
    'createtime'  => '创建时间',
    'updatetime'  => '更新时间'
];
