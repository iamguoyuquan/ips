<?php

return [
    'name'        => '姓名',
    'mobile'       => '手机',
    'avatar'       => '头像',
    'gender'       => '性别',
    'male'       => '男性',
    'female'       => '女性',
    
    'doctor'       => '治疗医生',
    'birth_year'       => '出生年份',
    'disease'       => '确诊病种',
    'diagnose_at'       => '确诊年份',
    'disease'       => '确诊病种',
    'address'       => '住址',
    'smoke'       => '吸烟情况',
    'memo'       => '备注',
    'medicine'       => '用药',
    'detail' => '详情',

    'createtime'  => '创建时间',
    'updatetime'  => '更新时间'
];
