<?php

return [
    'name'        => '姓名',
    'mobile'       => '手机',
    'avatar'       => '头像',
    'category'       => '分类',
    'gender'       => '性别',
    'male'       => '男性',
    'female'       => '女性',
    'title'       => '职称',
    'position'       => '医院职务',
    'wxid'       => '微信号',
    'wxgzh_qr'       => '公众号二维码',
    'wxgroup_qr'       => '群二维码',
    'createtime'  => '创建时间',
    'updatetime'  => '更新时间'
];
