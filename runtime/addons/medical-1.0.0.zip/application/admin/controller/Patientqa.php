<?php

namespace app\admin\controller;

use app\common\controller\Backend;

/**
 * 微信自动回复管理
 *
 * @icon fa fa-circle-o
 */
class Patientqa extends Backend
{
    protected $model = null;
    protected $searchFields = '';

    public function _initialize()
    {
        parent::_initialize();
        $this->relationSearch = true;
        $this->model = model('MedicalPatientqa');
    }

    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($where)
                ->order($sort, $order)
                ->count();
    
            $list = $this->model
                ->with(["patient"])
                ->where($where)
                ->order($sort, $order)
                ->limit($offset, $limit)
                ->select();
    
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);
    
            return json($result);
        }
        return $this->view->fetch();
    }



    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params['createtime'] = time();
            if ($params) {
                // list($province,$city,$area) = explode("/",$params['area']);
                // $params['province'] = $province;
                // $params['city'] = $city;
                // $params['area'] = $area;
                $this->model->save($params);
                $this->success();
                $this->content = $params;
            }
            $this->error();
        }
        return $this->view->fetch();
    }
    /**
     * 编辑
     */
   public function edit($ids = NULL)
   {
       $where = array();
       $where['medical_patientqa.id']=['IN',$ids];

       $row =$this->model
       ->alias('qa')
       ->with(["patient"])
       ->where($where)
       ->find();


    //    $where['qa.id']=['IN',$ids];

    //    $tb_qa = new Model('medical_patient_qa');
    //    $tb_p = new Model('medical_patient');

    //    $row = $tb_qa->alias('qa')->where($where)
    //    ->join('tb_p as p on p.id = qa.patient_id')
    //    ->find();




       if (!$row)
           $this->error(__('No Results were found'));
       if ($this->request->isPost()) {
           $params = $this->request->post("row/a");
           if ($params) {
               $row->save($params);
               $this->success();
           }
           $this->error();
       }

       $row['name'] = $row['patient_id'];
       $this->view->assign("row", $row);
       return $this->view->fetch();
   }

   function history(){
        $patient_id = $this->request->post("patient_id");
        
        if (!$patient_id) {
            $this->error(__('patient not found'));
        }

        $where = array();
        $where['patient_id']=['=',$patient_id];

        $list =$this->model
        ->where($where)
        ->order('createtime desc')
        ->limit(20)
        ->select();
        
        $this->success('', null, $list);
    }
}
