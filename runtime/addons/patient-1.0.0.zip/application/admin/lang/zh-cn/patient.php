<?php

return [
    'Text'                => '文本',
    'Event key'           => '响应标识',
    'Remark'              => '备注',
    'Text already exists' => '文本已经存在',
];
